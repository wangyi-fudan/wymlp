#include	<sys/time.h>
#include	<algorithm>
#include	<iostream>
#include	<stdint.h>
#include	<unistd.h>
#include	<fstream>
#include	"wymlp.hpp"
#include	"wyhash.h"
#include	<vector>
using	namespace	std;
typedef	double	type;

bool	load_matrix(const	char	*F,	vector<type>	&M,	unsigned	&R,	unsigned	&C) {
	ifstream	fi(F);
	if(!fi) {	cerr<<"fail to open "<<F<<'\n';	return	false;	}
	string	buf;	R=C=0;
	while(getline(fi,buf))	if(buf.size()) {
		char	*p=(char*)buf.data(),	*q;
		for(;;) {	
			q=p;	type	x=strtod(p,	&p);
			if(p!=q)	M.push_back(x);	else	break;
		}
		R++;
	}
	fi.close();
	if(M.size()%R) {	cerr<<"unequal column\t"<<F<<'\n';	return	false;	}
	C=M.size()/R;	cerr<<F<<'\t'<<R<<'*'<<C<<'\n';
	return	true;
}

void	document(void) {
	cerr<<"Usage:	train [options] X Y model\n";
	cerr<<"\t-a:	learning rate	default=0.01\n";
	cerr<<"\t-n:	#epoches	default=16\n";
	exit(0);
}

int	main(int	ac,	char	**av){
	unsigned	t0=time(NULL);
	cerr<<"***********************************\n";
	cerr<<"* wyrnn_train                      *\n";
	cerr<<"* author: Yi Wang                 *\n";
	cerr<<"* email:  godspeed_china@yeah.net *\n";
	cerr<<"* date:   16/Aug/2019             *\n";
	cerr<<"***********************************\n";
	type	eta=0.01;	size_t	epoches=16;
	int	opt;
	while((opt=getopt(ac,	av,	"e:n:"))>=0) {
		switch(opt) {
		case	'e':	eta=atof(optarg);	break;
		case	'n':	epoches=atoi(optarg);	break;
		default:	document();
		}
	}
	if(ac<optind+3)	document();

	vector<type>	xmat,	ymat,	data;	unsigned	sample,	sample1,	xsize,	ysize,	feature;
	if(!load_matrix(av[optind],	xmat,	sample,	xsize))	return	0;
	if(!load_matrix(av[optind+1],	ymat,	sample1,	ysize))	return	0;
	if(sample!=sample1)	return	0;
	feature=ysize+xsize;
	data.resize(sample*feature);
	for(size_t	i=0;	i<sample;	i++){
		for(size_t	j=0;	j<ysize;	j++)	data[i*feature+j]=ymat[i*ysize+j];
		for(size_t	j=0;	j<xsize;	j++)	data[i*feature+ysize+j]=xmat[i*xsize+j];
	}
	vector<type>().swap(xmat);	vector<type>().swap(ymat);
	vector<type>	mean(feature),	prec(feature);
	ofstream	fo("variable.txt");
	for(size_t	j=0;	j<feature;	j++){
		double	sx=0,	sxx=0;
		for(size_t	i=0;	i<sample;	i++){	type	x=data[i*feature+j];	sx+=x;	sxx+=x*x;	}
		sx/=sample;	sxx=sqrt(sxx/sample-sx*sx);	type	m=mean[j]=sx,	p=prec[j]=sxx>0?1/sxx:0;
		for(size_t	i=0;	i<sample;	i++)	data[i*feature+j]=(data[i*feature+j]-m)*p;
		fo<<m<<'\t'<<p<<'\n';		
	}
	fo.close();
	vector<bool>	trte;	for(size_t	i=0;	i<sample;	i++)	trte.push_back(wyhash64(i,0)&15);
	wymlp<type,12,4,16,1,0>	model;	model.random(t0);	wysrand(t0);
	timeval	beg,	end;	gettimeofday(&beg,NULL);
	uint64_t	flops=0;
	for(size_t	e=0;	e<epoches;	e++){
		for(size_t	i=0;	i<sample;	i++){
			uint64_t	ran;
			do	ran=wygrand()%sample;	while(!trte[ran]);
			model.model(data.data()+ran*feature+ysize,	data.data()+ran*feature,	eta);
			flops++;
		}
	}
	gettimeofday(&end,NULL);
	double	loss=0;	size_t	n=0;
	for(size_t	i=0;	i<sample;	i++)	if(!trte[i]){
		type	o[ysize],	l;
		model.model(data.data()+i*feature+ysize,	o,	-1);
		l=(data[i*feature]-o[0])*(data[i*feature]-o[0]);
		loss+=l;
		n++;
	}
	cerr<<sqrt(loss/n)/prec[0]<<'\n';
	type	deltat=(end.tv_sec-beg.tv_sec)+1e-6*(end.tv_usec-beg.tv_usec);
	cerr<<"time\t"<<deltat<<"s\n";
	cerr<<"FPS\t"<<(unsigned)(flops/deltat)<<'\n';
	model.save(av[optind+2]);
	return	0;
}
